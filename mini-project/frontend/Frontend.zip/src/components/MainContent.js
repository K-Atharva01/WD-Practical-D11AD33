import React from "react";

function MainContent(){
    return(
        <main className="maincontent">
            <h1></h1>
        </main>
    )
}

return default MainContent;