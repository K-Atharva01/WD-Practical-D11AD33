import React, { useRef, useState } from "react";
import { Form, Button, Card, Alert } from "react-bootstrap";
import { useAuth } from "../contexts/AuthContext";
import Spinner from "react-bootstrap/Spinner";

export default function TestTeacher() {
  return (
    <>
      <Card>
        <Card.Body>
          <h2 className="text-center mb-4">Sign Up</h2>
          
        </Card.Body>
      </Card>

    </>
  );
}
